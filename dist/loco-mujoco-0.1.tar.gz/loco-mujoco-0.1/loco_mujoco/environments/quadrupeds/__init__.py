from .unitreeA1 import UnitreeA1

# register environment
UnitreeA1.register()
