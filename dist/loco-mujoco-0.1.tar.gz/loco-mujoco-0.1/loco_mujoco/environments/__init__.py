from .base import LocoEnv, ValidTaskConf
from .humanoids import *
from .quadrupeds import *
