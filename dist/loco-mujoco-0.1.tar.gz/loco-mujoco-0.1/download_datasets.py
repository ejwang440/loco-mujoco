import loco_mujoco

loco_mujoco.download_all_datasets()
